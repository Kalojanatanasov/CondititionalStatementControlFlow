﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03.ControlFlowConditionalStatement
{
    class Refactored3
    {
        const int DEVILNUMBER = 666;

        static void Main(string[] args)
        {
            int i = 0;
            int expectedValue = DEVILNUMBER;
            int[] array = new int[100];
            int lengthArray = array.Length;

            //TO DO array initialization with Random Number

            for (i = 0; i < lengthArray; i++)
            {
                Console.WriteLine(array[i]);
                
                if (i % 10 == 0 && (array[i] == expectedValue))
                {
                    i = DEVILNUMBER;
                    Console.WriteLine("Value Found");
                    break;
                }
            }
        }
    }
}

           