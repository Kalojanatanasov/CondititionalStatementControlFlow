﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.ControlFlowConditionalStatement
{
   public class Peel
    {
        /// <summary>
        /// Method here check is the vegitable peeled or not if id true we can't do the same operation again
        /// </summary>
        /// <param name="vegitable">any vegitable</param>
        public void PeelVegitable(Vegetable vegitable)
        {
            if (vegitable.IsPeeled == true)
            {
                throw new FieldAccessException("We can't peel already peeled product!");
            }
            else
            {
                vegitable.IsPeeled = true;
            }
        }
    }
}
