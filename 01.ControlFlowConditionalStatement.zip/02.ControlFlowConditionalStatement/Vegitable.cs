﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.ControlFlowConditionalStatement
{
    /// <summary>
    /// Implement some state of the vegitable, boiled, peeled, rotten, cut 
    /// </summary>
    public abstract class Vegetable
    {
        private bool isBoiled = false;
        private bool isPeeled = false;
        private bool isRotten = false;
        private bool isCut = false;

        public bool IsRotten
        {
            get
            {
                return this.isRotten;
            }
            set
            {
                isRotten = value;
            }
        }

        public bool IsPeeled
        {
            get
            {
                return this.isPeeled;
            }
            set
            {
                isPeeled = value;
            }
        }

        public bool IsBoiled
        {
            get
            {
                return this.isBoiled;
            }
            set
            {
                isBoiled = value;
            }
        }

        public bool IsCut
        {
            get
            {
                return this.isCut;
            }
            set
            {
                isCut = value;
            }
        }

        public override string ToString()
        {
            return this.GetType().Name;
        }
    }
}
