﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.ControlFlowConditionalStatement
{
    class Refactored2
    {
        const int MIN_X = int.MinValue;
        const int MAX_X = int.MaxValue;
        const int MIN_Y = int.MinValue;
        const int MAX_Y = int.MaxValue;

        private static void Cook(Vegetable vegitable)
        {
            Bowl bowl;
            PeelVegitable(vegitable);
            CutVegitable(vegitable);
            bowl = GetBowl(vegitable);
            bowl.BowlProduct(vegitable);
        }

        private static Potato GetPotato()
        {
            return new Potato();
        }

        private static Bowl GetBowl(Vegetable vegitable)
        {
            return new Bowl();
        }

        private static Cut CutVegitable(Vegetable vegitable)
        {
            return new Cut();
        }

        private static Peel PeelVegitable(Vegetable vegitable)
        {
            return new Peel();
        }

        static void Main(string[] args)
        {
            Potato potato = new Potato();
            if (potato != null)
            {

                if ((potato.IsRotten != true) && (potato.IsPeeled == true))
                {
                    Cook(potato);
                }
            }

            //TO DO: connect two code?!
            int x=1, y=1, x1=0, y1=0;
            int[,] visited = new int[x,y];
            int[,] currentVisited = new int[x1, y1];
            bool xIsInRange = ((MIN_X <= x) && (x <= MAX_X));
            bool yIsInRange = ((MIN_Y <= y) && (y <= MAX_Y));

            if (xIsInRange && yIsInRange && visited[x, y]==currentVisited[x1,y1])
            {
                VisitCell(x, y);
            }
        }

        private static void VisitCell(int x, int y)
        {
            throw new NotImplementedException("We must implement VisitCell to make program working");
        }
    }
}