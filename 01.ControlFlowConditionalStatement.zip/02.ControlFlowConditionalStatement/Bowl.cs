﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.ControlFlowConditionalStatement
{
   public class Bowl
    {
        /// <summary>
        /// Method here check is the vegitable boiled/rotten or not if id true we can't do the same operation again
        /// </summary>
        /// <param name="vegitable">any vegitable</param>
        public void BowlProduct(Vegetable vegitable)
        {
            if (vegitable.IsBoiled == true)
            {
                throw new FieldAccessException("Vegitable property must not be cook before cooking!");
            }
            if (vegitable.IsRotten == true)
            {
                throw new FieldAccessException("We cannot cook with rotten vegitables!");
            }
            else
            {
                vegitable.IsBoiled = true;
            }
        }
    }
}
