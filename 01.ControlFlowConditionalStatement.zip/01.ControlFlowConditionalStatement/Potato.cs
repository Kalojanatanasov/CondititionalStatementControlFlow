﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ControlFlowConditionalStatement
{
    /// <summary>
    /// Carrot is child of Vegitable and implement all of his methods
    /// </summary>
    public class Potato : Vegetable
    {
    }
}
