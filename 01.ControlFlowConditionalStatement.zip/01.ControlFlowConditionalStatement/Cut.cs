﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ControlFlowConditionalStatement
{
   public class Cut
    {
        /// <summary>
        /// Method here check is the vegitable cut or not if id true we can't do the same operation again
        /// </summary>
        /// <param name="vegitable">any vegitable</param>
       public void CutProduct(Vegetable vegitable)
       {
           if (vegitable.IsCut == true)
           {
               throw new FieldAccessException("We can't cut already cuted product!");
           }
           else
           {
               vegitable.IsCut = true;
           }
       }
    }
}
