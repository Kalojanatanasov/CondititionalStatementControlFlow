﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ControlFlowConditionalStatement
{
    class Chef
    {
        static void Main()
        {
            Potato potato = GetPotato();            
            Carrot carrot = GetCarrot();

            Cook(potato); 
            Cook(carrot);                                               
        }

        private static void Cook(Vegetable vegitable)
        {
            Bowl bowl;
            PeelVegitable(vegitable);
            CutVegitable(vegitable);
            bowl = GetBowl(vegitable);
            bowl.BowlProduct(vegitable);            
        }

        private static Potato GetPotato()
        {
            return new Potato();
        }

        private static Carrot GetCarrot()
        {
            return new Carrot();
        }

        private static Bowl GetBowl(Vegetable vegitable)
        {
            return new Bowl();
        }

        private static Cut CutVegitable(Vegetable vegitable)
        {
           return new Cut();
        }

        private static Peel PeelVegitable(Vegetable vegitable)
        {
            return new Peel();
        }
    }
}

   